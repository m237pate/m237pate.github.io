# MPatel Web Legacy

Archive of assets from the original Colorlib "Beckham" Bootstrap 4 portfolio template that ran maharshipatel.me before the Stitch redesign (May 2026).

## What's in here

| Path | What it is |
|---|---|
| `css/` | Original CSS — Bootstrap, animate.css, AOS, Owl Carousel, magnific-popup, jquery.timepicker, ionicons, icomoon, flaticon, and the compiled `style.css`. |
| `js/` | jQuery + supporting plugins (popper, bootstrap, owl carousel, AOS, scrollax, stellar, magnific-popup, datepicker, waypoints, easing, animate-number, google-map.js, main.js). |
| `fonts/` | Icon font sets (flaticon, icomoon, ionicons, open-iconic) — superseded by Google Material Symbols Outlined in the new design. |
| `scss/` | SASS source for the old Colorlib template (`style.scss` + Bootstrap partials). |
| `images/` | Colorlib placeholder photos (person_1–4, work-1–6, image_1–6) plus IRS.JPG, e5_bridge.jpg, and loc.png that the original site used. |
| `prepros-6.config` | Build config for Prepros (Colorlib's SCSS/JS compiler workflow). |

## Why it's archived (not deleted outright)

- **Recoverability** — if anything in the new Stitch site is missing or needs a reference, the original markup conventions and assets are here.
- **History** — git already preserves the old HTML files, but the raw template assets (icon fonts, SCSS partials) bulked up the repo and are no longer touched at build/serve time.

## What replaced it (in the live site root)

- HTML: `index.html`, `about.html`, `portfolio.html`, `contact.html`, `project-wind.html` — all rebuilt against the Stitch design system.
- CSS: `css/stitch.css` (single file).
- JS: `js/stitch-config.js` (Tailwind runtime config), `js/stitch-nav.js` (mobile drawer + form helpers).
- Tailwind via CDN (no build step).
- Fonts via Google Fonts CDN (Plus Jakarta Sans, Inter, JetBrains Mono, Material Symbols).

## Restoring

If you ever need to put the old site back, you can unzip the parent archive into the repo root — but you'll also need to revert the HTML files via `git log` since they were overwritten in place.
